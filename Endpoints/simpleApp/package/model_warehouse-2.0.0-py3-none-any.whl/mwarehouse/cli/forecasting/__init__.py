from ._nn_mono import predict_mono_nn
from ._traditional_mono import predict_mono_traditional
