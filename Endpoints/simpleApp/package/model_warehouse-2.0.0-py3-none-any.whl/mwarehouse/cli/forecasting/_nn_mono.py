import os
import warnings

import click

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Prevent tf logging information

from mwarehouse.forecasting.models.networks import multi_input, single_input
from mwarehouse.forecasting.preprocessing import simple_ts_split, NnTsGenerator
from mwarehouse.io import read_and_format_ts, write_and_format
from mwarehouse.utils import build_info_path

warnings.filterwarnings('ignore')  # Reduce future warnings


@click.command()
@click.option('--input_path', required=True, type=click.Path(exists=True))
@click.option('--output_path', required=True, type=click.Path(exists=False))
@click.option('--time_column', required=True, type=str)
@click.option('--label_column', required=True, type=str)
@click.option('--frequency', required=True, type=str)
@click.option('--date_format', required=False, default='%d.%m.%Y', type=str)
@click.option('--horizon', required=True, type=int)
@click.option('--holdout', required=True, type=int)
@click.option('--shift', required=True, type=int)
@click.option('--input_width', required=True, type=int)
@click.option('--train_size', required=False, default=0.7, type=float)
@click.option('--max_epochs', required=True, default=15, type=int)
@click.option('--sin_cos', required=False, default=True, type=bool)
def predict_mono_nn(input_path: str, output_path: str,
                    time_column: str, label_column: str,
                    frequency: str, date_format: str, horizon: int, holdout: int, shift: int, input_width: int,
                    train_size: float, max_epochs: int, sin_cos: bool) -> None:
    click.echo('--------------- Initialize Data and Models ---------------')
    data = read_and_format_ts(
        input_path=input_path,
        time_column=time_column,
        date_format=date_format,
        sort=False
    )

    sgl_train_df, sgl_val_df, sgl_test_df, sgl_scaler, sgl_future_frame = simple_ts_split(
        data,
        time_column=time_column,
        holdout=holdout,
        shift=shift,
        train_size=train_size,
        frequency=frequency,
        sin_cos_features=sin_cos
    )

    multi_train_df, multi_val_df, multi_test_df, multi_scaler, multi_future_frame = simple_ts_split(
        data,
        time_column=time_column,
        holdout=holdout + input_width - 1,
        shift=shift,
        train_size=train_size,
        frequency=frequency,
        sin_cos_features=sin_cos
    )

    single_window = NnTsGenerator(
        train_df=sgl_train_df,
        val_df=sgl_val_df,
        test_df=sgl_test_df,
        input_width=1,
        label_width=1,
        shift=shift,
        label_columns=[label_column],
    )

    print('SINGLE:', single_window)

    for example_inputs, example_labels in single_window.train.take(1):
        print(f'Inputs shape (batch, time, features): {example_inputs.shape}')
        print(f'Labels shape (batch, time, features): {example_labels.shape}')

    for example_inputs, example_labels in single_window.train.take(1):
        for i in [0]:
            print(example_inputs[i])
            print(example_labels[i])

    multi_window = NnTsGenerator(
        train_df=multi_train_df,
        val_df=multi_val_df,
        test_df=multi_test_df,
        input_width=input_width,
        label_width=1,
        shift=shift,
        label_columns=[label_column],
    )

    print('MULTI:', multi_window)

    for example_inputs, example_labels in multi_window.train.take(1):
        print(f'Inputs shape (batch, time, features): {example_inputs.shape}')
        print(f'Labels shape (batch, time, features): {example_labels.shape}')

    for example_inputs, example_labels in multi_window.train.take(1):
        for i in [0]:
            print(example_inputs[i])
            print(example_labels[i])

    single_dense_model = single_input.SingleDense(
        data_generator=single_window,
        future_frame=sgl_future_frame,
        scaler=sgl_scaler,
        max_epochs=max_epochs
    )

    single_recurrent_model = single_input.SingleRecurrent(
        data_generator=single_window,
        future_frame=sgl_future_frame,
        scaler=sgl_scaler,
        max_epochs=max_epochs
    )

    single_residual_model = single_input.SingleResidual(
        data_generator=single_window,
        future_frame=sgl_future_frame,
        scaler=sgl_scaler,
        max_epochs=max_epochs
    )

    multi_dense_model = multi_input.MultiDense(
        data_generator=multi_window,
        future_frame=multi_future_frame,
        scaler=multi_scaler,
        max_epochs=max_epochs
    )

    multi_conv_model = multi_input.MultiConvolution(
        data_generator=multi_window,
        future_frame=multi_future_frame,
        scaler=multi_scaler,
        max_epochs=max_epochs
    )

    multi_recurrent_model = multi_input.MultiRecurrent(
        data_generator=multi_window,
        future_frame=multi_future_frame,
        scaler=multi_scaler,
        max_epochs=max_epochs
    )

    print('--------------- Initial Model Selection ---------------')

    single_dense_model.fit(
        baseline=True
    )
    single_recurrent_model.fit(
        baseline=True
    )
    single_residual_model.fit(
        baseline=True
    )
    multi_dense_model.fit(
        baseline=True
    )
    multi_conv_model.fit(
        baseline=True
    )
    multi_recurrent_model.fit(
        baseline=True
    )
    print('MAPEs of during Model Selection: ')
    print('Single Dense Model:', single_dense_model.initial_mape)
    print('Single Recurrent Model:', single_recurrent_model.initial_mape)
    print('Single Residual Model:', single_residual_model.initial_mape)
    print('Multi Dense Model:', multi_dense_model.initial_mape)
    print('Multi Conv Model:', multi_conv_model.initial_mape)
    print('Multi Recurrent Model:', multi_recurrent_model.initial_mape)

    print('\n\nInitial Model selection in terms of MAPE: ')
    model_accuracies = list()

    model_accuracies.append(single_dense_model.initial_mape)
    model_accuracies.append(single_recurrent_model.initial_mape)
    model_accuracies.append(single_residual_model.initial_mape)
    model_accuracies.append(multi_dense_model.initial_mape)
    model_accuracies.append(multi_conv_model.initial_mape)
    model_accuracies.append(multi_recurrent_model.initial_mape)

    best = model_accuracies.index(min(model_accuracies))
    if best == 0:
        print('BEST MODEL IS:', 'single_dense_model')
        selected_model = single_dense_model
        selected_model_name = 'single_dense_model'
    elif best == 1:
        print('BEST MODEL IS:', 'single_recurrent_model')
        selected_model = single_recurrent_model
        selected_model_name = 'single_recurrent_model'
    elif best == 2:
        print('BEST MODEL IS:', 'single_residual_model')
        selected_model = single_residual_model
        selected_model_name = 'single_residual_model'
    elif best == 3:
        print('BEST MODEL IS:', 'multi_dense_model')
        selected_model = multi_dense_model
        selected_model_name = 'multi_dense_model'
    elif best == 4:
        print('BEST MODEL IS:', 'multi_conv_model')
        selected_model = multi_conv_model
        selected_model_name = 'multi_conv_model'
    else:
        print('BEST MODEL IS:', 'multi_recurrent_model')
        selected_model = multi_recurrent_model
        selected_model_name = 'multi_recurrent_model'

    print('--------------- Hyper-Parameter Search ---------------')
    selected_model.fit(
        hp_search=True
    )
    hp_mape = selected_model.global_best_precision['mape']
    print('MAPE after HP-Search is: ', hp_mape)

    print('--------------- Final Training ---------------')
    selected_model.fit(
        final_training=True
    )

    print('--------------- Predictions ---------------')
    raw_prediction_frame, predictions = selected_model.final_predictions(horizon=horizon, frequency=frequency,
                                                                         time_column=time_column)

    print('--------------- Writing Predictions to Drive'.format(output_path))

    if holdout - horizon != 0:
        predictions = predictions.iloc[:-(holdout - horizon)]

    write_and_format(predictions, output_path)

    info_file = build_info_path(input_path=input_path, output_path=output_path)

    with open(info_file, 'w') as file:
        file.write('MAES of during Model Selection: ')
        file.write('\nSingle Dense Model: {}'.format(single_dense_model.initial_mape))
        file.write('\nSingle Recurrent Model: {}'.format(single_recurrent_model.initial_mape))
        file.write('\nSingle Residual Model: {}'.format(single_residual_model.initial_mape))
        file.write('\nMulti Dense Model: {}'.format(multi_dense_model.initial_mape))
        file.write('\nMulti Conv Model: {}'.format(multi_conv_model.initial_mape))
        file.write('\nMulti Recurrent Model: {}'.format(multi_recurrent_model.initial_mape))
        file.write('\n\nSelected Model: {}'.format(selected_model_name))
        file.write('\nMAE after HP-Search: {}'.format(hp_mape))

    print('--------------- Process Finished: Data is at {} ---------------'.format(output_path))


if __name__ == '__main__':
    import mwarehouse.datasets
    import mwarehouse.tests.forecasting.networks
    import os

    predict_mono_nn([
        "--input_path",
        os.path.join(os.path.join(os.path.dirname(mwarehouse.datasets.__file__), 'data'), 'weather_data_MonthEnd.csv'),
        "--output_path",
        os.path.join(os.path.join(os.path.dirname(mwarehouse.tests.forecasting.networks.__file__), 'temp_output'),
                     'test_output.csv'),
        "--time_column", "Date",
        "--label_column", "T (degC)",
        "--frequency", "M",
        "--date_format", "%Y-%m-%d",
        "--horizon", "5",
        "--holdout", "10",
        '--shift', "1",
        "--input_width", "7",
        '--train_size', "0.7",
        '--max_epochs', "2",
    ])
