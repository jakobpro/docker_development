from abc import ABC, abstractmethod

import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error

from mwarehouse.forecasting.postprocessing import merge_predictions
from mwarehouse.forecasting.utils import inverse_scale


class AbstractTraditionalForecaster(ABC):

    @abstractmethod
    def __init__(self, data_generator, scaler):
        self.frequency = data_generator.frequency

        # Data for model_selection
        self.train = data_generator.train
        self.val = data_generator.val

        # Data for Hyper-Parameter search
        self.hp_train = {'inputs': pd.concat([self.train['inputs'], self.val['inputs']]),
                         'targets': pd.concat([self.train['targets'], self.val['targets']])}
        self.test = data_generator.test

        # Data for final training
        self.final_train = {'inputs': pd.concat([self.hp_train['inputs'], self.test['inputs']]),
                            'targets': pd.concat([self.hp_train['targets'], self.test['targets']])}

        # Data for prediction
        self.future_frame = data_generator.future
        self.raw_future = data_generator.raw_future

        self.label_index = data_generator.label_columns.argmax()
        self.time_index = self.raw_future.columns.get_loc(data_generator.time_column)
        self.scaler = scaler

        # Final Model
        self.final_model = None

    @abstractmethod
    def _fit(self, config: list, data: dict):
        pass

    @abstractmethod
    def _parallel_fit(self, config: dict, data: dict, val_data: dict):
        pass

    @abstractmethod
    def fit(self, baseline: bool, hp_search: bool, final_training: bool):
        pass

    @abstractmethod
    def predict(self, model, start: int, prediction_frame: dict):
        pass

    def final_predictions(self):
        predictions = self.predict(model=self.final_model,
                                   start=len(self.final_train['inputs']),
                                   prediction_frame=self.future_frame)

        scaled_predictions = inverse_scale(self.scaler, self.label_index, predictions.values)
        self.raw_future.iloc[:, self.label_index] = inverse_scale(self.scaler, self.label_index,
                                                                  self.raw_future.iloc[:, self.label_index].values)
        prd_frame = merge_predictions(
            predictions=scaled_predictions,
            future=self.raw_future,
            time_index=self.time_index,
            label_index=self.label_index,
            offset=0,
            frequency=self.frequency
        )

        return predictions, prd_frame

    def _calc_metrics(self, pred, true):
        mse = mean_squared_error(y_true=true, y_pred=pred)
        mae = mean_absolute_error(y_true=true, y_pred=pred)
        mape = self.mean_absolute_percentage_error(y_true=true, y_pred=pred)

        return {'mse': mse, 'mae': mae, 'mape': mape}

    def mean_absolute_percentage_error(self, y_true, y_pred):
        y_true = inverse_scale(self.scaler, self.label_index, y_true)
        y_pred = inverse_scale(self.scaler, self.label_index, y_pred)

        mask = (y_true != 0)
        y_true_clean = y_true[mask]
        y_pred_clean = y_pred.to_numpy().reshape(-1, 1)[mask]

        n_dropped = len(y_true) - len(y_true_clean)
        if n_dropped > 0:
            print('{} zero-values have been dropped in favour of MAPE calculation.'.format(n_dropped))

        mape = np.abs(y_pred_clean - y_true_clean) / np.abs(y_true_clean)
        output_errors = np.average(mape, weights=None, axis=0) * 100
        return output_errors
