import random
from datetime import datetime
from multiprocessing import Pool

import numpy as np
import statsmodels.api as sm
import tqdm

from . import AbstractTraditionalForecaster
from ...utils import test_stationarity, find_D, find_d


class Sarimax(AbstractTraditionalForecaster):

    def __init__(self, data_generator, scaler, max_individuals: int, max_epochs: int,
                 max_p: int, max_q: int, max_d: int, max_s_p: int, max_s_q: int, max_s_d: int,
                 seasonal_period, seasonal: bool = False, parallel: bool = True):
        super().__init__(data_generator=data_generator, scaler=scaler)

        # Seasonality Information
        self.seasonal = seasonal
        if seasonal:
            if seasonal_period:
                self.seasonal_period = seasonal_period
            else:
                self.seasonal_period = test_stationarity(self.train['targets'])
        else:
            self.seasonal_period = 0

        # Differencing Information
        if self.seasonal_period > 1:
            self.seasonal_D = find_D(self.train['targets'], self.seasonal_period, max_D=max_s_d)
        else:
            self.seasonal_D = 0
        self.normal_d = find_d(self.train['targets'])
        if self.normal_d > max_d:
            self.normal_d = max_d

        # Max Params for Model Selection
        self.max_p = max_p
        self.max_q = max_q
        self.max_d = max_d
        self.max_P = max_s_p
        self.max_Q = max_s_q
        self.max_D = max_s_d

        # Params for Time Restriction
        self.max_individuals = max_individuals
        self.max_epochs = max_epochs

        # Initial Metrics
        self.initial_population = self._initial_parameters()
        self.blacklist = list()
        self.global_best_model = None

        self.global_best_aic = np.inf
        self.space_aic = dict()

        self.global_best_precision = dict()
        self.space_precision = dict()

        self.parallel = parallel

    def _initial_parameters(self):
        """
        General: Generates traditional Sarimax class for predictions. This object inherits the AbstractTraditionalForecaster Class
        Config info:
        1. The (p,d,q) order of the model for the number of AR parameters, differences, and MA parameters. d must be an integer indicating the integration order of the process, while p and q may either be an integers indicating the AR and MA orders (so that all lags up to those orders are included) or else iterables giving specific AR and / or MA lags to include. Default is an AR(1) model: (1,0,0).
        2. The (P,D,Q,s) order of the seasonal component of the model for the AR parameters, differences, MA parameters, and periodicity. may either be an integers indicating the AR and MA orders (so that all lags up to those orders are included) or else iterables giving specific AR and / or MA lags to include. s is an integer giving the periodicity (number of periods in season), often it is 4 for quarterly data or 12 for monthly data. Default is no seasonal effect.        D must be an integer indicating the integration order of the process, while P and Q 
        
        """
        if self.seasonal_period <= 1:
            configs = [((2, self.normal_d, 2), (0, 0, 0, 0)),
                       ((0, self.normal_d, 0), (0, 0, 0, 0)),
                       ((1, self.normal_d, 0), (0, 0, 0, 0)),
                       ((0, self.normal_d, 1), (0, 0, 0, 0))]
        else:
            configs = [((2, self.normal_d, 2), (0, 0, 0, 0)),
                       ((0, self.normal_d, 0), (0, 0, 0, 0)),
                       ((1, self.normal_d, 0), (0, 0, 0, 0)),
                       ((0, self.normal_d, 1), (0, 0, 0, 0)),
                       ((2, self.normal_d, 2), (1, self.seasonal_D, 1, self.seasonal_period)),
                       ((0, self.normal_d, 0), (0, self.seasonal_D, 0, self.seasonal_period)),
                       ((1, self.normal_d, 0), (1, self.seasonal_D, 0, self.seasonal_period)),
                       ((0, self.normal_d, 1), (0, self.seasonal_D, 1, self.seasonal_period))]
        return configs

    def _next_generation(self):
        configs = list()

        # Initial Values
        init_p = self.global_best_model[0][0]
        init_d = self.global_best_model[0][1]
        init_q = self.global_best_model[0][2]

        init_s_p = self.global_best_model[1][0]
        init_s_d = self.global_best_model[1][1]
        init_s_q = self.global_best_model[1][2]

        # Random Variation
        selected_param = random.choice([(0, 0), (0, 2), (1, 0), (1, 2)])

        if selected_param == (0, 0):
            extended_values = self._limited_range(init_p, self.max_p)
            configs.extend(self.generator(extended_values, [init_d], [init_q], [init_s_p], [init_s_d], [init_s_q]))
        elif selected_param == (0, 2):
            extended_values = self._limited_range(init_q, self.max_q)
            configs.extend(self.generator([init_p], [init_d], extended_values, [init_s_p], [init_s_d], [init_s_q]))
        elif selected_param == (1, 0):
            extended_values = self._limited_range(init_s_p, self.max_P)
            configs.extend(self.generator([init_p], [init_d], [init_q], extended_values, [init_s_d], [init_s_q]))
        else:
            extended_values = self._limited_range(init_s_q, self.max_Q)
            configs.extend(self.generator([init_p], [init_d], [init_q], [init_s_p], [init_s_d], extended_values))

        # Systematic Variation
        p_values = self._limited_range(init_p, self.max_p)
        q_values = self._limited_range(init_q, self.max_q)

        configs.extend(self.generator(p_values, [init_d], q_values, [init_s_p], [init_s_d], [init_s_q]))

        s_p_values = self._limited_range(init_s_p, self.max_P)
        s_q_values = self._limited_range(init_s_q, self.max_Q)
        configs.extend(self.generator([init_p], [init_d], [init_q], s_p_values, [init_s_d], s_q_values))

        return list(set(configs))

    def generator(self, p_values: list, d_value: list, q_values: list,
                  s_p_values: list, s_d_value: list, s_q_values: list):
        """
        Possible Modification
        b = list(itertools.product(p_values, d_values, q_values, ))
        c = list(itertools.product(s_p_values, s_d_values, s_q_values, [seasonal_period]))
        bc = list(itertools.filterfalse(lambda x: x in blacklist, itertools.product(b,c)))

        :param p_values:
        :param d_value:
        :param q_values:
        :param s_p_values:
        :param s_d_value:
        :param s_q_values:
        :return:
        """
        configs = list()
        if self.seasonal_period > 1:
            for p in p_values:
                for d in d_value:
                    for q in q_values:
                        for P in s_p_values:
                            for D in s_d_value:
                                for Q in s_q_values:
                                    cfg = ((p, d, q), (P, D, Q, self.seasonal_period))
                                    if cfg not in self.blacklist:
                                        configs.append(cfg)
            return configs
        else:
            for p in p_values:
                for d in d_value:
                    for q in q_values:
                        cfg = ((p, d, q), (0, 0, 0, 0))
                        if cfg not in self.blacklist:
                            configs.append(cfg)
            return configs

    def _fit(self, config: tuple, data: dict):
        model = sm.tsa.SARIMAX(endog=data['targets'], exog=data['inputs'],
                               order=config[0], seasonal_order=config[1],
                               enforce_stationarity=False, enforce_invertibility=False,
                               freq=self.frequency).fit(disp=False, method='lbfgs', low_memory=True)

        return model

    def _parallel_fit(self, config: tuple, data: dict, val_data: dict):
        try:
            res = self._fit(config=config, data=data)
            predictions = self.predict(model=res, start=len(data['targets']), prediction_frame=val_data)

            precision = self._calc_metrics(true=val_data['targets'].values, pred=predictions)

            aic = res.aic

            return {config: {'aic': aic, 'precision': precision}}
        except ValueError:
            return {config: {'aic': np.inf, 'precision': {'mae': np.inf, 'mse': np.inf, 'mape': np.inf}}}

    def fit(self, baseline: bool = False, hp_search: bool = False, final_training: bool = False):
        if baseline:
            base_conf = random.sample(population=self.initial_population, k=1)[0]
            self.blacklist.append(base_conf)
            self.initial_population.remove(base_conf)

            res = self._parallel_fit(config=base_conf, data=self.train, val_data=self.val)

            self.global_best_model = base_conf
            self.global_best_aic = res[base_conf]['aic']
            self.global_best_precision = res[base_conf]['precision']

        elif hp_search:
            population = self.initial_population

            for epoch in range(1, self.max_epochs + 1):

                print('----- Starting Round {} \n'.format(epoch))
                print('Fitting {} models.'.format(len(population)))

                start_time = datetime.now()
                if self.parallel:
                    args = ((config, self.hp_train, self.test) for config in population)
                    with Pool() as pool:
                        results = pool.starmap(self._parallel_fit, tqdm.tqdm(args, total=len(population)))
                else:
                    results = list()
                    for config in tqdm.tqdm(population):
                        results.append(self._parallel_fit(config=config, data=self.hp_train, val_data=self.test))

                duration = round((datetime.now() - start_time).total_seconds(), 2)

                print('Finished Round {} in {} seconds \n'.format(epoch, duration))
                for sgl_res in results:
                    for key, value in sgl_res.items():
                        self.blacklist.append(key)
                        self.space_aic[key] = value['aic']
                        self.space_precision[key] = value['precision']

                best_params = min(self.space_aic, key=self.space_aic.get)
                local_best_metric = self.space_aic[best_params]
                local_best_precision = self.space_precision[best_params]
                if local_best_metric < self.global_best_aic:
                    print('Better parameters were found\n')
                    print('Params: {}'.format(best_params))
                    print('Precision: {}'.format(local_best_precision))
                    self.global_best_model = best_params
                    self.global_best_aic = local_best_metric
                    self.global_best_precision = local_best_precision
                else:
                    print('----- Performance did not improve! Stopping HP-Search')
                    break

                population = self._next_generation()

                if len(population) == 0:
                    print('----- No more combinations available! Stopping HP-Search')
                    break

                if len(population) > self.max_individuals:
                    population = random.sample(population, k=self.max_individuals)

        elif final_training:
            self.final_model = self._fit(config=self.global_best_model, data=self.final_train)

        return self

    def predict(self, model, start: int, prediction_frame: dict):

        end = start + len(prediction_frame['inputs']) - 1
        exog = prediction_frame['inputs']

        predictions = model.predict(start=start, end=end, exog=exog, dynamic=True)
        return predictions

    @staticmethod
    def _limited_range(num: int, maximum: int):
        lower_bound = num - 1
        upper_bound = num + 2
        return list(range(max(min(lower_bound, maximum + 1), 0), max(min(upper_bound, maximum + 1), 0)))
