import tensorflow as tf

from .._AbstractNetworkForecaster import AbstractNetworkForecaster


class SingleRecurrent(AbstractNetworkForecaster):
    """Recurrent network for single prediction """

    def _build_baseline_model(self):
        """ Erstelle Basis Modell für Single-LSTM
        Parameters:
        return_seq: True --> Der Layer gibt ein Output für jeden Input, sinnvoll beim Training eines Modells
        auf mehreren Zeitschritten gleichzeitig oder beim Stapeln von RNN-Schichten
        Returns
        -------

        """
        model = tf.keras.Sequential()
        # Shape [batch, time, features] => [batch, time, lstm_units]
        return_seq = True

        model.add(
            tf.keras.layers.LSTM(32, return_sequences=return_seq, name='LSTM_1')
        )
        # Shape => [batch, time, features]
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense')
        )

        return self._compile_model(model, hp=None)

    def _build_advanced_model(self, hp):
        """ Erstelle erweitertes Modell für Single-LSTM mit HPO

        Parameters
        ----------
        hp: Objekt der Hyperparameter für die Hyperparameteroptimierung

        Returns
        -------

        """
        model = tf.keras.Sequential()
        num_layers = hp.Int('num_layers', 1, 5)
        for i in range(num_layers):
            n_units = hp.Int('units_' + str(i), min_value=16, max_value=80, step=16)
            model.add(
                # Shape [batch, time, features] => [batch, time, lstm_units]
                tf.keras.layers.LSTM(n_units,
                                     return_sequences=True,
                                     name='LSTM_' + str(i)),
            )
        # Shape => [batch, time, features]
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense')
        )
        return self._compile_model(model, hp)
