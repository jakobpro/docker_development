from ._multi_dense import MultiDense
from ._multi_recurrent import MultiRecurrent
from ._multi_convolution import MultiConvolution
