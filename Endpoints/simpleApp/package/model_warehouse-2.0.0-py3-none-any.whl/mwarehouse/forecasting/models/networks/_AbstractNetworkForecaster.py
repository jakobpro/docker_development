import os
import sys
from abc import ABC, abstractmethod

import keras_tuner as kt
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.python.framework import ops
from tensorflow.python.keras import backend as K
from tensorflow.python.ops import math_ops

from mwarehouse.forecasting.postprocessing import merge_predictions
from mwarehouse.forecasting.utils import inverse_scale


class AbstractNetworkForecaster(ABC):

    def __init__(self, data_generator, future_frame: pd.DataFrame, scaler, max_epochs):
        # Data for model_selection
        self.train = data_generator.train
        self.val = data_generator.val

        # Data for hparam search
        self.hp_train = self.train.concatenate(self.val)
        self.test = data_generator.test

        # Data for final trainig
        self.final_train = self.hp_train.concatenate(self.test)

        # Data for prediction
        self.future_frame = future_frame

        # Prediction Meta
        self.input_width = data_generator.input_width
        self.shift = data_generator.shift
        self.label_column = data_generator.label_columns[0]
        self.label_index = self.future_frame.columns.get_loc(self.label_column)
        self.num_features = data_generator.train_df.shape[1]
        self.scaler = scaler

        # Placeholder for Models
        self.base_model = self._build_baseline_model()
        self.tuner = None
        self.final_model = None
        self.max_epochs = max_epochs

        self.val_epoch = None
        self.val_loss = None
        self.initial_mape = None
        self.global_best_precision = {'mae': np.inf, 'mse': np.inf, 'mape': np.inf}

        self.metric_func = self.scaled_mean_absolute_percentage_error()

    @abstractmethod
    def _build_baseline_model(self):
        pass

    @abstractmethod
    def _build_advanced_model(self, hp):
        pass

    def _build_final_model(self):
        self.final_model = self.tuner.hypermodel.build(self.best_hps)
        return self

    def _compile_model(self, model, hp):
        if not hp:
            model.compile(
                optimizer=tf.keras.optimizers.Adam(
                    learning_rate=1e-4,
                ),
                loss=tf.losses.MeanSquaredError(),
                metrics=[
                    tf.metrics.MeanAbsoluteError(),
                    self.scaled_mean_absolute_percentage_error()
                ]
            )
        else:
            hp_optimizer = hp.Choice('optimizer', values=['ADAM', 'SGD'])
            if hp_optimizer == 'SGD':

                hp_learning_rate = hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])
                hp_momentum = hp.Choice('momentum', values=[1e-2, 1e-3, 1e-4])
                hp_nesterov = hp.Boolean('nesterov')

                model.compile(
                    optimizer=tf.optimizers.SGD(
                        learning_rate=hp_learning_rate,
                        momentum=hp_momentum,
                        nesterov=hp_nesterov,
                    ),
                    loss=tf.losses.MeanSquaredError(),
                    metrics=[
                        tf.metrics.MeanAbsoluteError(),
                        self.scaled_mean_absolute_percentage_error()
                    ]
                )
            else:
                hp_learning_rate = hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])
                model.compile(
                    optimizer=tf.keras.optimizers.Adam(
                        learning_rate=hp_learning_rate,
                    ),
                    loss=tf.losses.MeanSquaredError(),
                    metrics=[
                        tf.metrics.MeanAbsoluteError(),
                        self.scaled_mean_absolute_percentage_error()
                    ]
                )

        return model

    def _fit(self, callbacks: list, baseline: bool, hp_search: bool, final_training: bool,
             verbose: bool):
        if baseline:
            history = self.base_model.fit(
                self.train,
                epochs=self.max_epochs,
                validation_data=self.val,
                callbacks=callbacks,
                verbose=verbose,
            )
            self.val_epoch = np.argmin(history.history['val_mean_absolute_error'])
            self.val_loss = np.min(history.history['val_loss'])
            self.initial_mape = history.history['val_mean_absolute_percentage_error'][self.val_epoch]

        elif hp_search:
            self.tuner = kt.Hyperband(
                self._build_advanced_model,
                objective='val_mean_absolute_error',
                project_name=os.path.join(sys.path[2], 'temp_output'),
                overwrite=True,
                max_epochs=self.max_epochs,
                factor=3,
            )
            # TODO: Implement early stopping callback
            self.tuner.search(
                self.hp_train,
                epochs=self.max_epochs,
                validation_data=self.test,
            )
            self.best_hps = self.tuner.get_best_hyperparameters(num_trials=1)[0]
            for trial_id, trial_obj in self.tuner.oracle.trials.items():
                if trial_obj.hyperparameters == self.best_hps:
                    self.global_best_precision['mape'] = \
                        trial_obj.metrics.metrics['val_mean_absolute_percentage_error']._observations[0].value[0]
            self._build_final_model()
        elif final_training:
            self.final_model.fit(
                self.final_train,
                epochs=self.max_epochs*2,  # TODO: delete *2
                callbacks=callbacks,
                verbose=verbose,
            )
        return self

    def fit(self, callbacks: list = None, baseline: bool = False, hp_search: bool = False,
            final_training: bool = False, verbose: bool = True):
        if not callbacks:
            callbacks = []
        else:
            pass
        return self._fit(callbacks=callbacks, hp_search=hp_search, baseline=baseline,
                         final_training=final_training, verbose=verbose)

    def _predict(self, x: np.array):
        return self.final_model.predict(x)

    def final_predictions(self, horizon: int, frequency: str, time_column: str = 'Date'):
        prediction_frame = self.future_frame.copy()

        # Get time axis
        col_indexer = prediction_frame.columns != time_column
        time_indexer = prediction_frame.columns == time_column
        model_offset = self.shift + self.input_width - 1

        # Get predictions -> fill sales with nan in a copy of the prediction frame to simulate a "real" forecast
        prediction_frame.loc[model_offset:, self.label_column] = np.nan

        for i in range(0, horizon):
            #get last date in window (window slowly grows from 0 to horizon)
            last_obs_date = prediction_frame.iloc[i:self.input_width + i, time_indexer].iloc[-1, :]
            #get date to be predicted
            target_date = prediction_frame.loc[model_offset + i, time_indexer]
            #print("Last Obs:", last_obs_date)
            #print('To pred', target_date)

            #creates a stack from all values in window (if input_width = 1 then it does "nothing")
            prediction_data = tf.stack([prediction_frame.iloc[i:self.input_width + i, col_indexer].values])

            try:
                prediction = self._predict(prediction_data)[0][0][0]
            except IndexError:
                prediction = self._predict(prediction_data)[0][0]

            prediction_frame.loc[i + model_offset, self.label_column] = prediction

        predictions = prediction_frame.loc[model_offset:, self.label_column]

        scaled_predictions = inverse_scale(self.scaler, self.label_index, predictions.values)

        self.future_frame[self.label_column] = inverse_scale(self.scaler, self.label_index,
                                                             self.future_frame[self.label_column].values)

        prd_frame = merge_predictions(
            predictions=scaled_predictions,
            future=self.future_frame,
            time_index=self.future_frame.columns.get_loc(time_column),
            label_index=self.label_index,
            offset=model_offset,
            frequency=frequency
        )

        return prediction_frame, prd_frame

    def scaled_mean_absolute_percentage_error(self):
        def mean_absolute_percentage_error(y_true, y_pred):
            """Computes the mean absolute percentage error between `y_true` and `y_pred`.

            `loss = 100 * mean(abs((y_true - y_pred) / y_true), axis=-1)`

            Standalone usage:

            >>> y_true = np.random.random(size=(2, 3))
            >>> y_true = np.maximum(y_true, 1e-7)  # Prevent division by zero
            >>> y_pred = np.random.random(size=(2, 3))
            >>> loss = tf.keras.losses.mean_absolute_percentage_error(y_true, y_pred)
            >>> assert loss.shape == (2,)
            >>> assert np.array_equal(
            ...     loss.numpy(),
            ...     100. * np.mean(np.abs((y_true - y_pred) / y_true), axis=-1))

            Args:
              y_true: Ground truth values. shape = `[batch_size, d0, .. dN]`.
              y_pred: The predicted values. shape = `[batch_size, d0, .. dN]`.

            Returns:
              Mean absolute percentage error values. shape = `[batch_size, d0, .. dN-1]`.
            """
            y_true = inverse_scale(self.scaler, self.label_index, y_true, tf_op=True)
            y_pred = inverse_scale(self.scaler, self.label_index, y_pred, tf_op=True)
            y_pred = ops.convert_to_tensor_v2_with_dispatch(y_pred)
            # y_pred = ops.convert_to_tensor_v2(y_pred)  # for tensorflow versions lower than 2.4
            y_true = math_ops.cast(y_true, y_pred.dtype)
            diff = math_ops.abs(
                (y_true - y_pred) / K.maximum(math_ops.abs(y_true), K.epsilon()))
            return 100. * K.mean(diff, axis=-1)

        return mean_absolute_percentage_error

    @property
    def loss(self):
        return self.val_loss

    @property
    def epoch(self):
        return self.val_epoch
