import tensorflow as tf

from .._AbstractNetworkForecaster import AbstractNetworkForecaster


class ResidualWrapper(tf.keras.Model):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def call(self, inputs, *args, **kwargs):
        delta = self.model(inputs, *args, **kwargs)

        # The prediction for each timestep is the input
        # from the previous time step plus the delta
        # calculated by the model.
        return inputs + delta


class SingleResidual(AbstractNetworkForecaster):

    def _build_baseline_model(self):
        model = tf.keras.Sequential()
        model.add(
            # Shape [batch, time, features] => [batch, time, lstm_units]
            tf.keras.layers.LSTM(32, return_sequences=True, name='LSTM_1'),
        )
        model.add(
            tf.keras.layers.Dense(
                self.num_features,
                # The predicted deltas should start small
                # So initialize the output layer with zeros
                kernel_initializer=tf.initializers.zeros, name='Final_Dense')
        )
        model = ResidualWrapper(model)
        return self._compile_model(model, hp=None)

    def _build_advanced_model(self, hp):
        model = tf.keras.Sequential()
        num_layers = hp.Int('num_layers', 1, 5)
        for i in range(num_layers):
            n_units = hp.Int('units_' + str(i), min_value=16, max_value=80, step=16)
            model.add(
                # Shape [batch, time, features] => [batch, time, lstm_units]
                tf.keras.layers.LSTM(n_units,
                                     return_sequences=True,
                                     name='LSTM_' + str(i)),
            )
        model.add(
            tf.keras.layers.Dense(
                self.num_features,
                # The predicted deltas should start small
                # So initialize the output layer with zeros
                kernel_initializer=tf.initializers.zeros, name='Final_Dense')
        )
        model = ResidualWrapper(model)
        return self._compile_model(model, hp)
