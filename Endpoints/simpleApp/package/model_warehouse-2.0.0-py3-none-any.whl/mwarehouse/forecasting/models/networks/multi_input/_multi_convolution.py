import tensorflow as tf

from ...networks import AbstractNetworkForecaster


class MultiConvolution(AbstractNetworkForecaster):

    def _build_baseline_model(self):
        model = tf.keras.Sequential()
        model.add(
            tf.keras.layers.Conv1D(filters=32,
                                   kernel_size=(self.input_width,),
                                   activation='relu',
                                   name='Conv_1')
        )
        model.add(
            tf.keras.layers.Dense(units=32, activation='relu', name='Dense_1'),
        )
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense'),
        )
        return self._compile_model(model, hp=None)

    def _build_advanced_model(self, hp):
        model = tf.keras.Sequential()
        model.add(
            tf.keras.layers.Conv1D(filters=hp.Int('filters_1',
                                                  min_value=16,
                                                  max_value=80,
                                                  step=16),
                                   kernel_size=(int(self.input_width / 2),),
                                   activation='relu',
                                   name='Conv_1'),
        )
        model.add(
            tf.keras.layers.Conv1D(filters=hp.Int('filters_2',
                                                  min_value=16,
                                                  max_value=80,
                                                  step=16),
                                   kernel_size=(self.input_width - int((self.input_width / 2)) + 1,),
                                   activation='relu',
                                   name='Conv_2')
        )
        model.add(
            tf.keras.layers.Dense(units=32, activation='relu', name='Dense_1'),
        )
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense'),
        )
        return self._compile_model(model, hp)
