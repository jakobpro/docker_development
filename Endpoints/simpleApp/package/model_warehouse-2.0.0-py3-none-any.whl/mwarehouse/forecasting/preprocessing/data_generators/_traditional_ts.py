import pandas as pd


class TraditionalTsGenerator:
    def __init__(self, frequency: str, train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame = None,
                 future_df: pd.DataFrame = None, label_column: str = None, time_column: str = None):
        self.frequency = frequency

        # Store the raw data
        self.train_df = train_df
        self.val_df = val_df
        self.test_df = test_df
        self.future_df = future_df

        # Work out the label column indices
        self.label_columns = self.train_df.columns == label_column

        self.input_columns = self.train_df.columns != label_column

        self.time_column = time_column

    def make_dataset(self, data):
        targets = data.iloc[:, self.label_columns].asfreq(self.frequency, method='nearest')
        inputs = data.iloc[:, self.input_columns].asfreq(self.frequency, method='nearest')
        return {'inputs': inputs, 'targets': targets}

    @property
    def train(self):
        return self.make_dataset(self.train_df)

    @property
    def val(self):
        return self.make_dataset(self.val_df)

    @property
    def test(self):
        return self.make_dataset(self.test_df)

    @property
    def future(self):
        return self.make_dataset(self.future_df)

    @property
    def raw_future(self):
        raw_future = self.future_df.reset_index(drop=True)
        raw_future[self.time_column] = self.future_df.index
        return raw_future
