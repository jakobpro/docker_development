from ._sin_cos_time import _sin_cos_time as sincos_ts
