import datetime

import numpy as np
import pandas as pd


def _sin_cos_time(data: pd.DataFrame, frequency: str, date_column: str) -> pd.DataFrame:
    timestamp_s = data[date_column].map(datetime.datetime.timestamp)

    ## Minütliche Daten könnte man hier noch hinzufügen
    
    if frequency in ['H', 'BH']:
        hour = 24 * 60 * 60
        data['Hour sin'] = np.sin(timestamp_s * (2 * np.pi / hour))
        data['Hour cos'] = np.cos(timestamp_s * (2 * np.pi / hour))

    if frequency in ['H', 'BH', 'D', 'B']:
        weekday = 7 * 24 * 60 * 60
        data['WeekDay sin'] = np.sin(timestamp_s * (2 * np.pi / weekday))
        data['WeekDay cos'] = np.cos(timestamp_s * (2 * np.pi / weekday))

    if frequency in ['H', 'BH', 'D', 'B', 'W']:
        monthday = 30.436875 * 24 * 60 * 60
        data['MonthDay sin'] = np.sin(timestamp_s * (2 * np.pi / monthday))
        data['MonthDay cos'] = np.cos(timestamp_s * (2 * np.pi / monthday))

    year = 365.2425 * 24 * 60 * 60
    data['Year sin'] = np.sin(timestamp_s * (2 * np.pi / year))
    data['Year cos'] = np.cos(timestamp_s * (2 * np.pi / year))

    return data
