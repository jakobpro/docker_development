import pandas as pd
from pandas.api.types import is_datetime64_any_dtype as is_datetime

from datetime import datetime
import numpy as np

from sklearn.preprocessing import StandardScaler, MinMaxScaler

class DataFormater():

    def __init__(self, data, date_column, label_column, frequency = "D", format = "%Y-%m-%d", neg_to_null = False, drop_threshhold = 20) -> None:
        self.data = data.copy(deep=True)
        self.date_column = date_column
        self.label_column = label_column
        self.frequency = frequency
        self.format = format
        self.neg_to_null = neg_to_null
        self.drop_threshhold = drop_threshhold


    #add auto formating or sth like that
    def date_to_index(self, *further_colums):

        #if date/time in multiple colums, they can be combined
        for entry in further_colums:
            self.data[self.date_column] = self.data.apply(lambda r : datetime.combine(r[self.date_column],r[entry]),1)
            self.data.drop(entry, axis = 1,inplace = True)
        
        #if date/time entry isn't in datetime convert it
        if not is_datetime(self.data[self.date_column]):
            #first with given format
            try: 
                self.data[self.date_column] = pd.to_datetime(self.data[self.date_column], format = self.format)
            #if that doesn't work try to detect the format
            except:
                print("Date didn't match format, trying to infer it instead")
                self.data[self.date_column] = pd.to_datetime(self.data[self.date_column], infer_datetime_format=True)

        #set the index to the date/time
        if True:
             self.data.set_index(self.date_column, inplace = True)
       
        return self.data
    
    #convert categories to labels or one hot encoding
    def convert_category(self, list_label_encoding = [], drop_first_column = True):

        #convert all non numerical columns to dummies or labels
        non_numeric = self.data.select_dtypes(exclude=[np.number])

        for column in non_numeric:
            #list_label_encoding should include data where categories are hierarchical, otherwise use label encoding if too long otherwise
            if column in list_label_encoding or len(self.data[column].value_counts()) > 10:
                self.data[column] = self.data[column].astype('category')
                self.data[column] = self.data[column].cat.codes
            #one hot (dummies) enocding where first one column is dropped per default to avoid multicollinearity issue: https://www.analyticsvidhya.com/blog/2020/03/one-hot-encoding-vs-label-encoding-using-scikit-learn/
            #nan values get converted to 
            else:
                self.data =pd.concat([self.data, pd.get_dummies(self.data[column], drop_first = drop_first_column, prefix=column, dummy_na=True)], axis = 1)
                self.data.drop(column, axis = 1, inplace = True)

        return self.data
    
    #normalize all numeric data (not categorical though? - doing it now) https://scikit-learn.org/stable/modules/classes.html#module-sklearn.preprocessing
    def normalize(self, type = MinMaxScaler(feature_range=(0.01, 1.0))):
        #self.data.set_index(self.date_column, inplace = True)
        scaler = type
        scaler.fit(self.data)
        self.data = pd.DataFrame(scaler.transform(self.data), index = self.data.index, columns= self.data.columns)
        #self.data.reset_index(inplace = True)

        return scaler, self.data

    #fill missing data according so some criteria -> categorical data not an issue since it won't have nan values
    #by no way good 
    #nan.regex could be ex. '.*NA.*'
    def fill_missing(self, how_to_fill = "nearest", nan_regex = ""):

        if nan_regex:
            self.data.replace(nan_regex, np.NaN, regex=True )
        #drop column if too many missing values
        self.data.dropna(thresh = int(len(self.data)*(1-self.drop_threshhold)), axis = 1, inplace = True)
        
        #in no way shape or form optimal, but it atleast works
        self.data.fillna(method = "ffill", inplace=True)
        self.data.fillna(method = "bfill", inplace=True)        
        return self.data

    #fills missing data points to fullfill certain frequency
    def fill_dates(self):
        self.data = self.data.asfreq(self.frequency, method = "ffill")
        return self.data

        
    #aggregate date to some frequency, what to do with values? (especially categorical)
    def aggregate(self, frequency = "D",  sum_list = [], mean_list = [], max_list = [], min_list= [], std_list = [], common_list = [], all_mean = True):
        if all_mean:
           self.data = self.data.groupby(pd.Grouper(freq=frequency)).mean()
           return self.data


        def merge_dicts(*dicts):
            """
            Zusammenlegen der dictionaries: wenn Key noch nicht existiert, neuer Key in dict 
            - sonst: append existing Key um neuen Value

            :param dicts:
            :return:
            """
            d = {}
            for dict in dicts:
                for key in dict:
                    try:
                        d[key].append(dict[key])
                    except KeyError:
                        d[key] = [dict[key]]
            return d 

        def most_common(x):
            """

            :param x:
            :return:
            """
            return x.value_counts(dropna=False).index[0]
        
        #creates dictonaries from lists with appropriate values

        sum_dict = dict.fromkeys(sum_list, 'sum')
        mean_dict = dict.fromkeys(mean_list, 'mean')
        max_dict = dict.fromkeys(max_list, 'max')
        min_dict = dict.fromkeys(min_list, 'min')
        std_dict = dict.fromkeys(std_list, 'std')

        #merges dictionaries
        common_dict = dict.fromkeys(common_list, most_common)

        #groups on date with frequency while aggregating on methods saved in dictionary
        agg_dict = merge_dicts(sum_dict, mean_dict, max_dict, min_dict, std_dict, common_dict)
        self.data = self.data.groupby(pd.Grouper(freq=frequency)).agg(agg_dict)

        #convert multilevel column index so single 
        self.data.columns = [pair[0]+"_"+pair[1] for pair in self.data.columns]
        return self.data


    #if operations are not supported, take out df and update manualy
    def get_df(self):
        return self.data

    def set_df(self, df):
        self.data = df