import pandas as pd
from pandas.tseries.offsets import Hour, BusinessHour, Day, BusinessDay, Week, MonthBegin, MonthEnd


def _merge_prediction_frame(predictions: pd.DataFrame, future: pd.DataFrame, time_index: str, label_index: str,
                            offset: int, frequency: str):
    start_date = future.iloc[0, time_index]

    # Build clean DataFrame
    if frequency == "H":
        start_date = start_date + Hour(offset)
    elif frequency == "BH":
        start_date = start_date + BusinessHour(offset)
    elif frequency == "D":
        start_date = start_date + Day(offset)
    elif frequency == 'B':
        start_date = start_date + BusinessDay(offset)
    elif frequency == "W":
        start_date = start_date + Week(offset)
    elif frequency == 'MS':
        start_date = start_date + MonthBegin(offset)
    elif frequency == 'M':
        start_date = start_date + MonthEnd(offset)
    else:
        raise NotImplementedError('You have to provide a valid Frequency')

    prd_frame = pd.DataFrame({
        'FC': predictions,
        future.columns[time_index]: pd.date_range(start=start_date, periods=len(predictions), freq=frequency),
        future.columns[label_index]: future.iloc[offset:, label_index].values
    })

    return prd_frame
