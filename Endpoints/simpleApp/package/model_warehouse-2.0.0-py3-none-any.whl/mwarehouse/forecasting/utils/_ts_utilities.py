import numpy as np
from numpy.linalg import solve
from scipy.linalg import svd
from sklearn.linear_model import LinearRegression
from sklearn.utils.validation import column_or_1d, check_array
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import kpss


def _diff_vector(ts, lag):
    # compute the lag for a vector (not a matrix)
    n = ts.shape[0]
    lag = min(n, lag)  # if lag > n, then we just want an empty array back
    return ts[lag: n] - ts[: n - lag]  # noqa: E226


def _diff_matrix(ts, lag):
    # compute the lag for a matrix (not a vector)
    m, _ = ts.shape
    lag = min(m, lag)  # if lag > n, then we just want an empty array back
    return ts[lag: m, :] - ts[: m - lag, :]  # noqa: E226


def diff(ts, lag=1, differences=1):
    if any(v < 1 for v in (lag, differences)):
        raise ValueError('lag and differences must be positive (> 0) integers')

    fun = _diff_vector if ts.ndim == 1 else _diff_matrix
    res = ts

    # "recurse" over range of differences
    for i in range(differences):
        res = fun(res, lag)
        # if it ever comes back empty, just return it as is
        if not res.shape[0]:
            return res

    return res


"""Seasonality"""


def is_constant(ts):
    x = column_or_1d(ts)
    return (x == x[0]).all()


def test_stationarity(ts):
    # TODO: Modifiy accortind to https://www.statsmodels.org/stable/examples/notebooks/generated/stationarity_detrending_adf_kpss.html
    ts = column_or_1d(check_array(ts, ensure_2d=False, force_all_finite=True))

    dftest = adfuller(ts, autolag='AIC')

    return dftest[2]


def CH_test(ltrunc, Ne, Fhataux, frec, m):
    a = 0

    half_m = (m / 2) - 1
    n = frec.shape[0]
    n_features = Fhataux.shape[1]

    Omnw = np.zeros((n_features, n_features), dtype=np.float64, order='c')
    wnw = 1. - (np.arange(ltrunc, dtype=np.float64) + 1.) / (ltrunc + 1.)

    for k in range(ltrunc):
        Omnw = Omnw + \
               np.dot(Fhataux.T[:, k + 1:Ne],
                      Fhataux[:(Ne - (k + 1)), :]) * \
               wnw[k]

    Omfhat = (np.dot(Fhataux.T, Fhataux) + Omnw + Omnw.T) / float(Ne)

    sq = np.arange(0, m - 1, 2, dtype=np.int32)
    frecob = np.zeros(m - 1, dtype=np.int32, order='c')

    for i in range(n):
        v = frec[i]

        if v == 1 and i == half_m:
            frecob[sq[i]] = 1
        if v == 1 and i < half_m:
            frecob[sq[i]] = frecob[sq[i] + 1] = 1

    # sum of == 1
    for i in range(m - 1):
        if frecob[i] == 1:
            a += 1

    A = np.zeros((m - 1, a), dtype=np.int32, order='c')

    i = 0
    j = 0

    for i in range(m - 1):
        if frecob[i] == 1:
            A[i, j] = 1
            j += 1

    return A, np.dot(np.dot(A.T, Omfhat), A)


def sd_test(ts, m, nobs):
    frec = np.ones(int((m + 1) / 2), dtype=np.int)
    ltrunc = int(np.round(m * ((nobs / 100.0) ** 0.25)))

    R1 = seasonal_dummy(m, nobs)

    lmch = LinearRegression(normalize=True).fit(R1, ts)
    residuals = ts - lmch.predict(R1)

    Fhataux = (R1.T * residuals).T

    Fhat = Fhataux.cumsum(axis=0)
    Ne = Fhataux.shape[0]

    A, AtOmfhatA = CH_test(ltrunc, Ne, Fhataux, frec, m)

    sv = svd(AtOmfhatA, compute_uv=False)

    if sv.min() < np.finfo(sv.dtype).eps:
        return 0

    solved = solve(AtOmfhatA, np.identity(AtOmfhatA.shape[0]))
    return (1.0 / nobs ** 2) * solved.dot(A.T).dot(Fhat.T).dot(Fhat).dot(A).diagonal().sum()


def seasonal_dummy(m, nobs):
    tt = np.arange(nobs) + 1
    double_m = m * 2
    fmat = np.ones((nobs, double_m)) * np.nan
    pi = np.pi
    for i in range(1, m + 1):
        fmat[:, (2 * i) - 1] = np.sin(2 * pi * i * tt / m)

        fmat[:, 2 * (i - 1)] = np.cos(2 * pi * i * tt / m)

    return fmat[:, :m - 1]


"""Stationarity"""


def estimate_D(ts, m, nobs):
    chstat = sd_test(ts, m, nobs)
    crit_vals = (0.4617146, 0.7479655, 1.0007818,
                 1.2375350, 1.4625240, 1.6920200,
                 1.9043096, 2.1169602, 2.3268562,
                 2.5406922, 2.7391007)

    if m <= 12:
        return int(chstat > crit_vals[m - 2])  # R does m - 1...
    if m == 24:
        return int(chstat > 5.098624)
    if m == 52:
        return int(chstat > 10.341416)
    if m == 365:
        return int(chstat > 65.44445)
    return int(chstat > 0.269 * (m ** 0.928))


def find_D(ts, m, max_D=10):
    ts = column_or_1d(check_array(ts, ensure_2d=False, force_all_finite=True))

    nobs = ts.shape[0]

    if nobs < 2 * m + 5:
        return 0

    if m < 2:
        return 0

    D = 0
    dodiff = estimate_D(ts, m, nobs)
    while dodiff == 1 and D < max_D:
        D += 1
        ts = diff(ts, lag=m)

        if is_constant(ts):
            return D
        dodiff = estimate_D(ts, m, nobs)

    return D


def find_d(ts, max_d=5, alpha="1%"):
    ts = column_or_1d(check_array(ts, ensure_2d=False, force_all_finite=True))
    i = 0
    dftest = kpss(ts, nlags=i)
    while abs(dftest[0]) < abs(dftest[3][alpha]) and i <= max_d:
        i += 1
        dftest = kpss(ts, lags=i)
    return i + 1
