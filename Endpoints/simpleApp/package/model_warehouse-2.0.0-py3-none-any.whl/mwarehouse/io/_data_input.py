import pandas as pd


def read_and_format_ts(input_path: str, sep: str = ',', sort: bool = True,
                       time_column: str = 'Date', date_format: str = '%d.%m.%Y') -> pd.DataFrame:
    """
    Wrapper that allows additional validation of read in data

    :param input_path: path of input csv
    :param sep: separator of csv data
    :param sort: whether to sort the data regarding the data
    :param time_column: column containing the dates
    :param date_format: the date format of the data
    """
    data = pd.read_csv(input_path, sep=sep)
    try:
        data.loc[:, time_column] = pd.to_datetime(data[time_column], format=date_format)
    except ValueError:
        data.loc[:, time_column] = pd.to_datetime(data[time_column], format='%Y-%m-%d')

    if sort:
        return data.sort_values(by=time_column)
    else:
        return data
