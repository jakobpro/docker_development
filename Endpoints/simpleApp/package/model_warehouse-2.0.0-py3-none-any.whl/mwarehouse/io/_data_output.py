import pandas as pd


def write_and_format(data: pd.DataFrame, output_path: str, sep: str = ',', with_index: bool = False):
    """
    Wrapper that allows additional validation of read in data

    :param data: pandas DataFrame which should be written to disk
    :param output_path: path to write the data to
    :param sep: separator of csv data
    :param with_index: whether to store the index or not
    """
    data.to_csv(output_path, sep=sep, index=with_index)
