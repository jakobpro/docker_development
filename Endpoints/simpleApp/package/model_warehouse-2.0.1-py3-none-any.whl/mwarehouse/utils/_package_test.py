def addOne(n):
    return n+1