import datetime
import glob
import os


def _flush_directory(path, exclude=None) -> None:
    if exclude:
        files = glob.glob(path + '*[.!{}]'.format(exclude))
    else:
        files = glob.glob(path + '*')

    if len(files) == 0:
        print("Directory is already flushed.")
    else:
        for f in files:
            print('{} successfully removed'.format(f))
            os.remove(f)


def _build_info_path(input_path: str, output_path: str) -> str:
    output_dir = os.path.dirname(output_path)
    current_time = datetime.datetime.now().strftime('%d-%b-%y_%H-%M-%S')
    filename = '{}_info_{}.txt'.format(os.path.split(input_path)[-1].split('.')[0], current_time)
    return os.path.join(output_dir, filename)
