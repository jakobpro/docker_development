import glob
import os
from unittest import TestCase

import pandas as pd
from click.testing import CliRunner

import mwarehouse.datasets
from mwarehouse.cli.forecasting import predict_mono_nn
from mwarehouse.utils import flush_directory


class TestNnMonoPrediction(TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        flush_directory('temp_output/')

        dataset_dir = os.path.join(os.path.join(os.path.dirname(mwarehouse.datasets.__file__), 'data'), '*.csv')
        file_paths = glob.glob(dataset_dir)
        cls.data = dict()
        for file in file_paths:
            data_name = file.split('_')[-1].strip('.csv')
            cls.data[data_name] = file

        cls.max_epochs = 5

    def test__nn_mono_prediction_hourly(self):
        runner = CliRunner()
        input_path = self.data['Hourly']
        output_path = os.path.join('temp_output', 'hourly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "H"
        date_format = "%Y-%m-%d"
        horizon = 24
        holdout = 48
        shift = 24
        input_width = 24
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_business_hours(self):
        runner = CliRunner()
        input_path = self.data['BusinessHour']
        output_path = os.path.join('temp_output', 'business_hourly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "BH"
        date_format = "%Y-%m-%d"
        horizon = 24
        holdout = 24
        shift = 8
        input_width = 16
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_daily(self):
        runner = CliRunner()
        input_path = self.data['Daily']
        output_path = os.path.join('temp_output', 'daily_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "D"
        date_format = "%Y-%m-%d"
        horizon = 7
        holdout = 14
        shift = 1
        input_width = 14
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_business_daily(self):
        runner = CliRunner()
        input_path = self.data['BusinessDay']
        output_path = os.path.join('temp_output', 'business_daily_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "B"
        date_format = "%Y-%m-%d"
        horizon = 5
        holdout = 11
        shift = 1
        input_width = 7
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_weekly(self):
        runner = CliRunner()
        input_path = self.data['Weekly']
        output_path = os.path.join('temp_output', 'weekly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "W"
        date_format = "%Y-%m-%d"
        horizon = 4
        holdout = 4
        shift = 52
        input_width = 4
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_monthly_start(self):
        runner = CliRunner()
        input_path = self.data['MonthStart']
        output_path = os.path.join('temp_output', 'MonthStart_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "MS"
        date_format = "%Y-%m-%d"
        horizon = 4
        holdout = 4
        shift = 12
        input_width = 4
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])
        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__nn_mono_prediction_monthly_end(self):
        runner = CliRunner()
        input_path = self.data['MonthEnd']
        output_path = os.path.join('temp_output', 'MonthEnd_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "M"
        date_format = "%Y-%m-%d"
        horizon = 4
        holdout = 4
        shift = 12
        input_width = 4
        train_size = 0.7
        max_epochs = self.max_epochs
        sin_cos = True
        result = runner.invoke(
            predict_mono_nn,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--horizon", horizon,
                "--holdout", holdout,
                '--shift', shift,
                "--input_width", input_width,
                '--train_size', train_size,
                '--max_epochs', max_epochs,
                '--sin_cos', sin_cos,

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested horizon and forecast length do not match.'
        self.assertEqual(output_file.shape[0], horizon, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values
