import glob
import os
from unittest import TestCase

import pandas as pd
from click.testing import CliRunner

import mwarehouse.datasets
from mwarehouse.cli.forecasting import predict_mono_traditional
from mwarehouse.utils import flush_directory


class TestTraditionalMonoPrediction(TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        flush_directory('temp_output/')

        dataset_dir = os.path.join(os.path.join(os.path.dirname(mwarehouse.datasets.__file__), 'data'), '*.csv')
        file_paths = glob.glob(dataset_dir)
        cls.data = dict()
        for file in file_paths:
            data_name = file.split('_')[-1].strip('.csv')
            cls.data[data_name] = file

        cls.max_epochs = 5

    def test__traditional_mono_hourly(self):
        runner = CliRunner()
        input_path = self.data['Hourly']
        output_path = os.path.join('temp_output', 'hourly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "H"
        date_format = "%Y-%m-%d"
        holdout = 48
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_business_hours(self):
        runner = CliRunner()
        input_path = self.data['BusinessHour']
        output_path = os.path.join('temp_output', 'business_hourly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "BH"
        date_format = "%Y-%m-%d"
        holdout = 24
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_daily(self):
        runner = CliRunner()
        input_path = self.data['Daily']
        output_path = os.path.join('temp_output', 'daily_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "D"
        date_format = "%Y-%m-%d"
        holdout = 14
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_business_daily(self):
        runner = CliRunner()
        input_path = self.data['BusinessDay']
        output_path = os.path.join('temp_output', 'business_daily_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "B"
        date_format = "%Y-%m-%d"
        holdout = 11
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_weekly(self):
        runner = CliRunner()
        input_path = self.data['Weekly']
        output_path = os.path.join('temp_output', 'weekly_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "W"
        date_format = "%Y-%m-%d"
        holdout = 4
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_monthly_start(self):
        runner = CliRunner()
        input_path = self.data['MonthStart']
        output_path = os.path.join('temp_output', 'MonthStart_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "MS"
        date_format = "%Y-%m-%d"
        holdout = 4
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])
        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values

    def test__traditional_mono_monthly_end(self):
        runner = CliRunner()
        input_path = self.data['MonthEnd']
        output_path = os.path.join('temp_output', 'MonthEnd_output.csv')
        time_column = "Date"
        label_column = "T (degC)"
        frequency = "M"
        date_format = "%Y-%m-%d"
        holdout = 4
        train_size = 0.7
        sin_cos = True
        result = runner.invoke(
            predict_mono_traditional,
            [
                "--input_path", input_path,
                "--output_path", output_path,
                "--time_column", time_column,
                "--label_column", label_column,
                "--frequency", frequency,
                "--date_format", date_format,
                "--holdout", holdout,
                '--train_size', train_size,
                '--sin_cos', sin_cos,
                '--max_epochs', self.max_epochs

            ])

        self.assertEqual(result.exit_code, 0)  # process exited successfully

        msg = 'No output file was created at the path {}'.format(output_path)
        self.assertTrue(os.path.isfile(output_path), msg=msg)  # output file created
        output_file = pd.read_csv(output_path)

        msg = 'Requested holdout and forecast length do not match.'
        self.assertEqual(output_file.shape[0], holdout, msg=msg)  # forecast length

        msg = 'The method returned forecast values other than numeric.'
        for value in output_file[label_column].values:
            self.assertIsInstance(value, (float, int, complex), msg=msg)  # forecast values are numbers

        msg = 'The forecast consists of only one unique value. Check the prediction method.'
        self.assertGreater(output_file["FC"].value_counts().shape[0], 1, msg=msg)  # uniqueness of values
