import os
import warnings

import click
import pandas as pd

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

from mwarehouse.forecasting.models.traditional import HoltWinters, Sarimax
from mwarehouse.forecasting.preprocessing import simple_ts_split, TraditionalTsGenerator
from mwarehouse.io import read_and_format_ts, write_and_format
from mwarehouse.utils import build_info_path

warnings.filterwarnings('ignore')


@click.command()
@click.option('--input_path', required=True, type=click.Path(exists=True))
@click.option('--output_path', required=True, type=click.Path(exists=False))
@click.option('--time_column', required=True, type=str)
@click.option('--label_column', required=True, type=str)
@click.option('--frequency', required=True, type=str)
@click.option('--date_format', required=False, default='%d.%m.%Y', type=str)
@click.option('--holdout', required=True, type=int)
@click.option('--train_size', required=False, default=0.8, type=float)
@click.option('--max_epochs', required=True, default=5, type=int)
@click.option('--sin_cos', required=False, default=True, type=bool)
def predict_mono_traditional(input_path: str, output_path: str,
                             time_column: str, label_column: str,
                             frequency: str, date_format: str, holdout: int,
                             max_epochs: int, train_size: float, sin_cos: bool):
    print('--------------- Initialize Data and Models ---------------')
    data = read_and_format_ts(
        input_path=input_path,
        time_column=time_column,
        date_format=date_format,
        sort=False
    )

    sgl_train_df, sgl_val_df, sgl_test_df, sgl_scaler, sgl_future_frame = simple_ts_split(
        data,
        time_column=time_column,
        shift=0,
        holdout=holdout,
        train_size=train_size,
        set_ts_index=True,
        frequency=frequency,
        sin_cos_features=sin_cos
    )

    single_window = TraditionalTsGenerator(
        frequency=frequency,
        train_df=sgl_train_df,
        val_df=sgl_val_df,
        test_df=sgl_test_df,
        future_df=sgl_future_frame,
        label_column=label_column,
        time_column=time_column
    )

    hw_est = HoltWinters(data_generator=single_window, scaler=sgl_scaler, max_individuals=20,
                         seasonal_period=None, seasonal=True)

    sar_est = Sarimax(data_generator=single_window, scaler=sgl_scaler, max_individuals=20, max_epochs=max_epochs,
                      max_p=5, max_q=5, max_d=5,
                      max_s_p=5, max_s_q=5, max_s_d=5,
                      seasonal_period=None, seasonal=True)

    print('--------------- Initial Model Selection ---------------')

    hw_est.fit(baseline=True)
    sar_est.fit(baseline=True)

    hw_initial_precision = hw_est.global_best_precision['mape']
    sar_initial_precision = sar_est.global_best_precision['mape']

    print('MAPES of during Model Selection: ')
    print('Holt Winters:', hw_initial_precision)
    print('SARIMAX:', sar_initial_precision)

    print('\n\nInitial Model selection in terms of MAPE: ')

    if hw_est.global_best_precision['mape'] < sar_est.global_best_precision['mape']:
        print('BEST MODEL IS:', 'Holt Winters')
        selected_model = hw_est
        selected_model_name = 'Holt Winters'
    else:
        print('BEST MODEL IS:', 'SARIMAX')
        selected_model = sar_est
        selected_model_name = 'SARIMAX'

    print('--------------- Hyperparameter Search ---------------')
    selected_model.fit(
        hp_search=True
    )
    hp_mape = selected_model.global_best_precision['mape']
    print('MAPE after HP-Search is: ', hp_mape)

    print('--------------- Final Training ---------------')
    selected_model.fit(
        final_training=True
    )

    print('--------------- Predictions ---------------')
    raw_prediction_frame, predictions = selected_model.final_predictions()

    print('--------------- Writing Predictions to Drive'.format(output_path))

    write_and_format(predictions, output_path)

    info_file = build_info_path(input_path=input_path, output_path=output_path)

    # TODO: Add Note to file so that it gets explained that the hyperparemeter mape is larger than the inital mape
    # TODO: Add Input parameters to the txt data

    with open(info_file, 'w') as file:
        file.write('MAPES of during Model Selection: ')
        file.write('\nSARIMAX: {}'.format(sar_initial_precision))
        file.write('\nHolt Winters: {}'.format(hw_initial_precision))

        file.write('\n\nSelected Model: {}'.format(selected_model_name))
        file.write('\nMAPE after HP-Search: {}'.format(hp_mape))

    print('--------------- Process Finished: Data is at {} ---------------'.format(output_path))


if __name__ == '__main__':
    import mwarehouse.datasets
    import mwarehouse.tests.forecasting.networks
    import os

    predict_mono_traditional([
        "--input_path",
        os.path.join(os.path.join(os.path.dirname(mwarehouse.datasets.__file__), 'data'), 'weather_data_MonthEnd.csv'),
        "--output_path",
        os.path.join(os.path.join(os.path.dirname(mwarehouse.tests.forecasting.networks.__file__), 'temp_output'),
                     'test_output.csv'),
        "--time_column", "Date",
        "--label_column", "T (degC)",
        "--frequency", "M",
        "--date_format", "%Y-%m-%d",
        "--holdout", "10",
        '--train_size', "0.7",
        '--max_epochs', "10"
    ])
