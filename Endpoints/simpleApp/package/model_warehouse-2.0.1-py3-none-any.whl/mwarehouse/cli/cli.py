import click

from .forecasting import predict_mono_nn, predict_mono_traditional


@click.group()
def cli():
    """
    This function serves as the entry point for the cli and all its sub-commands.
    :return: None
    """
    pass


cli.add_command(predict_mono_nn)
cli.add_command(predict_mono_traditional)
