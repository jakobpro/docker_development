import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

#class which takes data as input on creation, but then allows for multiple types of visualizations
class Visualization():

    #constructor takes the base data frame aswell as which labels are relevant and the predictions frame from selected_model.final_predictions
    def __init__(self, data, date, label, prediction) -> None:
        
        #base dataframe 
        self.data = data[[date, label]]

        #collumn names
        self.date = date
        self.label = label

        #predictions df from selected_model.final_predictions
        self.prediction = prediction.set_index(self.date)
   

    def comparison(self, width = 'auto', maxTicks = 'auto', style = "matplot", saveToFile = False, saveToFileDefaultName = False):
        if style == "matplot":
            plt = self._comparisonMatplotlib(width, maxTicks)
        else:
            print("invalid style")

        if saveToFile:
            plt.savefig(f"Comparison_{self.label}_{style}.jpg", bbox_inches='tight')

        if saveToFileDefaultName:
            plt.savefig(f"Comparison.jpg", bbox_inches='tight')


    def forecast(self, ratio = 'auto', width = 'auto', maxTicks = 'auto', style = "matplot", saveToFile = False, saveToFileDefaultName = False):
        if style == "matplot":
            plt = self._forecastMatplotlib(ratio, width, maxTicks)
        else:
            print("invalid style")
        
        if saveToFile:
            plt.savefig(f"Forecast_{self.label}_{style}.jpg", bbox_inches='tight')

        if saveToFileDefaultName:
            plt.savefig(f"Forecast.jpg", bbox_inches='tight')
    
    
    #base visualization (axes, title, width)
    def _baseVisualization(self, width, title):

        fig, ax = plt.subplots() 
        fig.set_figwidth(width)
        
        
        plt.xlabel(self.date)
        plt.ylabel(self.label)
        plt.title(title)
        return fig, ax
    	
    #compares FC to actuall values in Matplotlib 
    def _comparisonMatplotlib(self, width, maxTicks):

        #auto gives decent value that will always work
        if width == 'auto':
            width = len(self.prediction) / 10
        if maxTicks == 'auto':
            maxTicks = np.floor(width / 1.5)
        
        fig, ax = self._baseVisualization(width, "Forcast compared to actual " + self.label)
        
        #plot fc and normal values
        ax.plot(self.prediction.index, self.prediction[self.label], '#8c8c8c', label = self.label)
        ax.plot(self.prediction.index, self.prediction.FC, '#ff6900', label = 'FC')
        
        #create ticks
        plt.xticks(rotation=45)
        ax.xaxis.set_major_locator(plt.MaxNLocator(maxTicks)) #reduces number of ticks, number doesn't seem to exactly correlate
        plt.legend()
        return plt

    #adds forcast to the end of data in Matplotlib
    #ratio defines size of forcast in graph vs. known_data -> ratio of 2 means FC is twice the size of known_data
    def _forecastMatplotlib(self, ratio, width, maxTicks):
        #auto gives decent value that will always work
        if ratio == 'auto':
            ratio = 2

        #cuts data so that a certain ratio between known_data and forcast is maintained
        known_data = self.data[[self.date, self.label]].loc[self.data[self.date] < self.prediction.index.values[0]]
        known_data_cut = known_data.iloc[-1*int(min(len(known_data), len(self.prediction) / ratio)):]
        
        #auto gives decent value that will always work
        if width == 'auto':
            width = (len(self.prediction) + len(known_data_cut))  / 10
        if maxTicks == 'auto':
            maxTicks = np.floor(width / 1.5)

        fig, ax = self._baseVisualization(width, "Timeseries with forecast of " + self.label)
        
        #first plots known data, then connects it to the forcast
        ax.plot(known_data_cut[self.date],  known_data_cut[self.label], '#8c8c8c',label = self.label)
        ax.plot(np.insert(self.prediction.index.values, 0, known_data_cut[self.date].tail(1), axis=0), np.insert(self.prediction.FC.values, 0, known_data_cut[self.label].tail(1), axis=0), '#ff6900' ,linestyle='dashed',label = 'FC')
        
        #creates ticks
        ax.xaxis.set_major_locator(plt.MaxNLocator(maxTicks)) #reduces number of ticks, number doesn't seem to exactly correlate
        plt.xticks(rotation=45)
        plt.legend()
        return plt

        