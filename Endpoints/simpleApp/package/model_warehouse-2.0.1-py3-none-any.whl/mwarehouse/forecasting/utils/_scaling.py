from tensorflow.python.keras import backend


def _unscale(scaler, index, values, tf_op: bool = False):
    scaler_min = scaler.min_[index]
    scaler_scale = scaler.scale_[index]

    if tf_op:
        return (values - backend.constant(scaler_min)) / backend.constant(scaler_scale)
    else:
        return (values - scaler_min) / scaler_scale
