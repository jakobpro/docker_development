import random
from multiprocessing import Pool

import numpy as np
import statsmodels.api as sm
import tqdm
from sklearn.model_selection import ParameterGrid

from . import AbstractTraditionalForecaster
from ...utils import test_stationarity


class HoltWinters(AbstractTraditionalForecaster):

    def __init__(self, data_generator, scaler, max_individuals: int = 20,
                 seasonal_period=None, seasonal: bool = False):
        super().__init__(data_generator=data_generator, scaler=scaler)

        # Seasonality Information
        self.seasonal = seasonal
        if seasonal:
            if seasonal_period:
                self.seasonal_period = seasonal_period
            else:
                self.seasonal_period = test_stationarity(self.train['targets'])
        else:
            self.seasonal_period = 0

        self.max_individuals = max_individuals
        self.initial_population = self._initial_parameters()

        self.global_best_model = None

        self.global_best_mse = np.inf
        self.space_mse = dict()

        self.global_best_precision = dict()
        self.space_precision = dict()

    def _initial_parameters(self):
        param_seq = [
            {
                'trend': ['add', 'mul'],
                'damped_trend': [True, False],
                'seasonal': ['add', 'mul'],
                'seasonal_periods': [self.seasonal_period, None],
            },
            {
                'trend': [None],
                'damped_trend': [False],
                'seasonal': ['add', 'mul'],
                'seasonal_periods': [self.seasonal_period, None],
            },
            {
                'trend': [None],
                'damped_trend': [False],
                'seasonal': [None],
                'seasonal_periods': [None],
            }
        ]
        configs = random.sample(population=list(ParameterGrid(param_seq)), k=self.max_individuals)

        return configs

    def _fit(self, config: dict, data: dict):
        model = sm.tsa.ExponentialSmoothing(endog=data['targets'],
                                            trend=config['trend'], damped_trend=config['damped_trend'],
                                            seasonal=config['seasonal'], seasonal_periods=config['seasonal_periods'],
                                            initialization_method='estimated', use_boxcox=True,
                                            freq=self.frequency).fit(method='L-BFGS-B', optimized=True)

        return model

    def _parallel_fit(self, config: dict, data: dict, val_data: dict):
        try:
            res = self._fit(config=config, data=data)
            predictions = self.predict(model=res, start=len(data['targets']), prediction_frame=val_data)

            precision = self._calc_metrics(true=val_data['targets'].values, pred=predictions)

            config = tuple(config.values())

            return {config: {'precision': precision}}
        except ValueError:
            config = tuple(config.values())
            return {config: {'precision': {'mae': np.inf, 'mse': np.inf, 'mape': np.inf}}}

    def fit(self, baseline: bool = False, hp_search: bool = False, final_training: bool = False):
        if baseline:
            base_conf = random.sample(population=self.initial_population, k=1)[0]
            self.initial_population.remove(base_conf)

            res = self._parallel_fit(config=base_conf, data=self.train, val_data=self.val)

            self.global_best_model = base_conf
            self.global_best_precision = res[tuple(base_conf.values())]['precision']

        elif hp_search:
            population = self.initial_population

            args = ((config, self.hp_train, self.test) for config in population)
            with Pool() as pool:
                results = pool.starmap(self._parallel_fit, tqdm.tqdm(args, total=len(population)))

            for sgl_res in results:
                for key, value in sgl_res.items():
                    self.space_mse[key] = value['precision']['mse']
                    self.space_precision[key] = value['precision']

            best_params = min(self.space_mse, key=self.space_mse.get)
            local_best_metric = self.space_mse[best_params]
            local_best_precision = self.space_precision[best_params]
            if local_best_metric < self.global_best_mse:
                self.global_best_model['damped_trend'] = best_params[0]
                self.global_best_model['seasonal'] = best_params[1]
                self.global_best_model['seasonal_periods'] = best_params[2]
                self.global_best_model['trend'] = best_params[3]
                self.global_best_mse = local_best_metric
                self.global_best_precision = local_best_precision

        elif final_training:
            self.final_model = self._fit(config=self.global_best_model, data=self.final_train)

        return self

    def predict(self, model, start: int, prediction_frame: dict):

        end = start + len(prediction_frame['inputs']) - 1

        predictions = model.predict(start=start,
                                    end=end)
        return predictions
