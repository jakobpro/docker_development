from ._single_dense import SingleDense
from ._single_recurrent import SingleRecurrent
from ._single_residual import SingleResidual
