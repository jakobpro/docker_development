import tensorflow as tf

from ...networks import AbstractNetworkForecaster


class MultiDense(AbstractNetworkForecaster):

    def _build_baseline_model(self):
        """

        Returns
        -------

        """
        model = tf.keras.Sequential()
        model.add(
            # Shape: (time, features) => (time*features)
            tf.keras.layers.Flatten(name='Flatten'),
        )
        model.add(
            tf.keras.layers.Dense(units=32, activation='relu', name='Dense_1'),
        )
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense'),
        )
        model.add(
            # Add back the time dimension.
            # Shape: (outputs) => (1, outputs)
            tf.keras.layers.Reshape([1, -1], name='Reshape'),
        )
        return self._compile_model(model, hp=None)

    def _build_advanced_model(self, hp):
        """

        Parameters
        ----------
        hp

        Returns
        -------

        """
        model = tf.keras.Sequential()
        model.add(
            # Shape: (time, features) => (time*features)
            tf.keras.layers.Flatten(name='Flatten')
        )
        for i in range(hp.Int('num_layers', 2, 10)):
            model.add(
                tf.keras.layers.Dense(units=hp.Int('units_' + str(i),
                                                   min_value=32,
                                                   max_value=128,
                                                   step=16),
                                      activation='relu',
                                      name='Dense_' + str(i - 1))
            )
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense')
        )
        model.add(
            # Add back the time dimension.
            # Shape: (outputs) => (1, outputs)
            tf.keras.layers.Reshape([1, -1], name='Reshape')
        )

        return self._compile_model(model, hp)
