import tensorflow as tf

from .._AbstractNetworkForecaster import AbstractNetworkForecaster


class SingleDense(AbstractNetworkForecaster):

    def _build_baseline_model(self):
        model = tf.keras.Sequential()
        model.add(
            tf.keras.layers.Dense(units=64, activation='relu', name='Dense_1')
        )
        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense')
        )
        return self._compile_model(model, hp=None)

    def _build_advanced_model(self, hp):
        model = tf.keras.Sequential()

        for i in range(hp.Int('num_layers', 2, 10)):
            model.add(
                tf.keras.layers.Dense(units=hp.Int('units_' + str(i),
                                                   min_value=32,
                                                   max_value=128,
                                                   step=16),
                                      activation='relu',
                                      name='Dense_' + str(i))
            )

        model.add(
            tf.keras.layers.Dense(units=1, name='Final_Dense')
        )
        return self._compile_model(model, hp)
