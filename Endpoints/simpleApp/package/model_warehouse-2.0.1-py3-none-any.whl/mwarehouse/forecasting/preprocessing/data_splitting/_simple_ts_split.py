import pandas as pd
from sklearn.preprocessing import MinMaxScaler

from ..feature_engineering import sincos_ts


def simple_ts_split(data: pd.DataFrame, time_column: str, frequency: str, holdout: int, shift: int,
                    train_size: float = 0.7, sin_cos_features: bool = False, set_ts_index: bool = False ):
    data = data.sort_values(by=time_column)
    if holdout > 1:
        if sin_cos_features:
            data = sincos_ts(data=data, frequency=frequency, date_column=time_column)

        future_frame = data.iloc[-(holdout + shift):]

        data = data.iloc[:-holdout]
    else:
        if sin_cos_features:
            raise Warning(
                'You want Sin Cos features without the provision of a future index. Please at least as much future rows with date as you want to forecast and specify the holdout respectively.')
        future_frame = data.iloc[:-1]

    # Train, test, validation split
    data_len = len(data)
    train_df = data[:int(data_len * train_size)]
    val_df = data[int(data_len * train_size) - shift:int(data_len * (train_size + 0.2))]
    test_df = data[int(data_len * (train_size + 0.2)) - shift:]

    
    # get time axis of frames
    train_time = train_df.pop(time_column).reset_index(drop=True)
    val_time = val_df.pop(time_column).reset_index(drop=True)
    test_time = test_df.pop(time_column).reset_index(drop=True)
    future_time = future_frame.pop(time_column).reset_index(drop=True)


    
    # Scaling
    #scaler = MinMaxScaler(feature_range=(0.01, 1.01))
    #scaler.fit(train_df)
    train_df = pd.DataFrame(data=train_df, columns=train_df.columns)
    val_df = pd.DataFrame(data=val_df, columns=val_df.columns)
    test_df = pd.DataFrame(data=test_df, columns=test_df.columns)
    future_frame = pd.DataFrame(data=future_frame, columns=future_frame.columns)


    if not set_ts_index:
        # Merge the time axis
        future_frame = future_frame.reset_index(drop = True)
        future_frame = future_frame.merge(future_time, how='outer', left_index=True, right_index=True)
    else:
        train_df.index = train_time
        val_df.index = val_time
        test_df.index = test_time
        future_frame.index = future_time 
    '''
    if set_ts_index:
        train_df = train_df.reset_index()
        val_df = val_df.reset_index()
        test_df = test_df.reset_index()
        future_frame = future_frame.reset_index()
    '''
        

    return train_df, val_df, test_df, future_frame #, scaler
